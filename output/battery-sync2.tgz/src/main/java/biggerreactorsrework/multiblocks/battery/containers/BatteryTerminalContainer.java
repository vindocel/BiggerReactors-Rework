package biggerreactorsrework.multiblocks.battery.containers;

import biggerreactorsrework.core.client.gui.GuiSync;
import biggerreactorsrework.core.registry.ContainerSupplier;
import biggerreactorsrework.core.registry.RegisterContainer;
import biggerreactorsrework.multiblocks.battery.BatteryItemHandler;
import biggerreactorsrework.multiblocks.battery.tiles.BatteryBaseTile;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ArmorSlot;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

import javax.annotation.Nonnull;

/**
 * Battery terminal menu, opened from any block of an assembled battery. Besides the readouts it holds the battery's
 * two item slots, the player's inventory and, on a side tab, the armor and offhand slots, as Mekanism's induction
 * matrix does (there they are only a convenience: worn armor is not charged).
 */
@RegisterContainer(name = "battery_terminal")
public class BatteryTerminalContainer extends AbstractContainerMenu implements GuiSync.IGUIPacketProvider {

    @RegisterContainer.Type
    public static MenuType<BatteryTerminalContainer> INSTANCE;
    @RegisterContainer.Supplier
    public static final ContainerSupplier SUPPLIER = BatteryTerminalContainer::new;

    /**
     * Item positions (one pixel inside the slot art), shared with the screen.
     */
    public static final int DISCHARGE_X = 147;
    public static final int DISCHARGE_Y = 21;
    public static final int CHARGE_X = 147;
    public static final int CHARGE_Y = 51;
    public static final int INVENTORY_Y = 93;
    public static final int ARMOR_X = -22;
    public static final int ARMOR_Y = 45;
    public static final int OFFHAND_Y = ARMOR_Y + 4 * 18 + 4;

    private static final int BATTERY_SLOTS = BatteryItemHandler.SLOTS;
    private static final int PLAYER_SLOTS = 36;
    private static final int ARMOR_SLOTS = 4;

    private static final EquipmentSlot[] ARMOR_ORDER = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final ResourceLocation[] ARMOR_ICONS = {InventoryMenu.EMPTY_ARMOR_SLOT_HELMET, InventoryMenu.EMPTY_ARMOR_SLOT_CHESTPLATE,
            InventoryMenu.EMPTY_ARMOR_SLOT_LEGGINGS, InventoryMenu.EMPTY_ARMOR_SLOT_BOOTS};

    private final BatteryBaseTile tileEntity;

    public BatteryTerminalContainer(int windowId, BlockPos blockPos, Player player) {
        super(INSTANCE, windowId);
        this.tileEntity = (BatteryBaseTile) player.level().getBlockEntity(blockPos);
        this.getGuiPacket();

        // The client's slots are filled by the menu sync; it only needs the same placement rules.
        IItemHandler items = !player.level().isClientSide() && tileEntity.nullableController() != null
                ? tileEntity.controller().items : new BatteryItemHandler(() -> {
        });
        this.addSlot(new SlotItemHandler(items, BatteryItemHandler.DISCHARGE_SLOT, DISCHARGE_X, DISCHARGE_Y));
        this.addSlot(new SlotItemHandler(items, BatteryItemHandler.CHARGE_SLOT, CHARGE_X, CHARGE_Y));

        Inventory inventory = player.getInventory();
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                this.addSlot(new Slot(inventory, column + row * 9 + 9, 8 + column * 18, INVENTORY_Y + row * 18));
            }
        }
        for (int column = 0; column < 9; column++) {
            this.addSlot(new Slot(inventory, column, 8 + column * 18, INVENTORY_Y + 58));
        }

        for (int i = 0; i < ARMOR_ORDER.length; i++) {
            EquipmentSlot slot = ARMOR_ORDER[i];
            this.addSlot(new ArmorSlot(inventory, player, slot, 36 + slot.getIndex(), ARMOR_X, ARMOR_Y + i * 18, ARMOR_ICONS[i]));
        }
        this.addSlot(new Slot(inventory, 40, ARMOR_X, OFFHAND_Y) {
            @Override
            public void setByPlayer(@Nonnull ItemStack newStack, @Nonnull ItemStack oldStack) {
                player.onEquipItem(EquipmentSlot.OFFHAND, oldStack, newStack);
                super.setByPlayer(newStack, oldStack);
            }
        }.setBackground(InventoryMenu.BLOCK_ATLAS, InventoryMenu.EMPTY_ARMOR_SLOT_SHIELD));
    }

    /**
     * @return The current state of the machine.
     */
    @Override
    public GuiSync.IGUIPacket getGuiPacket() {
        return this.tileEntity.batteryState();
    }

    @Override
    public boolean stillValid(@Nonnull Player player) {
        // Any block of the battery opens this menu, so it stays open while that block is part of an assembled
        // battery and the player is within reach of it.
        return !tileEntity.isRemoved() && tileEntity.isBatteryAssembled()
                && player.distanceToSqr(tileEntity.getBlockPos().getCenter()) <= 64.0;
    }

    @Override
    public void executeRequest(String requestName, Object requestData) {
        assert tileEntity.getLevel() != null;
        if (tileEntity.getLevel().isClientSide) {
            runRequest(requestName, requestData);
            return;
        }
        tileEntity.runRequest(requestName, requestData);
    }

    @Nonnull
    @Override
    public ItemStack quickMoveStack(@Nonnull Player player, int index) {
        Slot slot = this.slots.get(index);
        if (!slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        int playerStart = BATTERY_SLOTS;
        int hotbarStart = playerStart + 27;
        int playerEnd = playerStart + PLAYER_SLOTS;
        int armorStart = playerEnd;

        if (index < playerStart || index >= armorStart) {
            // Out of the battery or the armor tab: back into the inventory.
            if (!this.moveItemStackTo(stack, playerStart, playerEnd, true)) {
                return ItemStack.EMPTY;
            }
        } else {
            // From the inventory: a battery slot that takes it, then a matching armor slot, then the other half of
            // the inventory, the way vanilla moves items between the main inventory and the hotbar.
            boolean moved = this.moveItemStackTo(stack, 0, BATTERY_SLOTS, false)
                    || this.moveItemStackTo(stack, armorStart, armorStart + ARMOR_SLOTS, false);
            if (!moved) {
                moved = index < hotbarStart
                        ? this.moveItemStackTo(stack, hotbarStart, playerEnd, false)
                        : this.moveItemStackTo(stack, playerStart, hotbarStart, false);
            }
            if (!moved) {
                return ItemStack.EMPTY;
            }
        }

        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        if (stack.getCount() == original.getCount()) {
            return ItemStack.EMPTY;
        }
        slot.onTake(player, stack);
        return original;
    }

    @Override
    public BlockPos machinePos() {
        return this.tileEntity.getBlockPos();
    }
}
