package biggerreactorsrework.multiblocks.battery.client;

import biggerreactorsrework.client.CommonRender;
import biggerreactorsrework.client.GuiArt;
import biggerreactorsrework.client.GuiFrame;
import biggerreactorsrework.client.GuiIcon;
import biggerreactorsrework.client.GuiTheme;
import biggerreactorsrework.core.client.gui.RenderHelper;
import biggerreactorsrework.core.client.gui.elements.RenderedElement;
import biggerreactorsrework.core.client.gui.elements.TooltipElement;
import biggerreactorsrework.core.client.gui.screens.ModScreen;
import biggerreactorsrework.multiblocks.battery.containers.BatteryTerminalContainer;
import biggerreactorsrework.multiblocks.battery.state.BatteryState;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.List;

import static biggerreactorsrework.multiblocks.battery.containers.BatteryTerminalContainer.*;

/**
 * Battery terminal: the charge bar, the stored energy and the last tick's input and output, the discharge and charge
 * slots on the right, the limits the cells give, the player's inventory, and the armor and offhand slots on a tab on
 * the left, laid out like Mekanism's induction matrix in the mod's own style.
 */
@OnlyIn(Dist.CLIENT)
public class BatteryTerminalScreen extends ModScreen<BatteryTerminalContainer> {

    private static final int WIDTH = 176;
    private static final int HEIGHT = 175;
    private static final int READOUT_X = 50;
    private static final int READOUT_WIDTH = DISCHARGE_X - 3 - READOUT_X;
    /**
     * Slot rings: cyan where energy flows into the battery, amber where it flows out to the item.
     */
    private static final int DISCHARGE_RING = 0xFF36CFEE;
    private static final int CHARGE_RING = 0xFFF0A23C;
    private static final int RING = 22;
    /**
     * Armor tab: four armor slots, a gap, the offhand slot, and the ear's padding around them.
     */
    private static final int ARMOR_EAR_Y = ARMOR_Y - 5;
    private static final int ARMOR_EAR_HEIGHT = OFFHAND_Y + 18 + 3 - ARMOR_EAR_Y;

    private final BatteryState batteryState;

    public BatteryTerminalScreen(BatteryTerminalContainer container, Inventory playerInventory, Component title) {
        super(container, playerInventory, Component.translatable("screen.biggerreactorsrework.battery_terminal"), WIDTH, HEIGHT);
        this.batteryState = (BatteryState) this.getMenu().getGuiPacket();
    }

    @Override
    public void init() {
        super.init();
        this.titleLabelX = (this.imageWidth - this.font.width(this.getTitle())) / 2;

        this.addScreenElement(new TooltipElement<>(this, 30, 18, 16, 16, Component.translatable("screen.biggerreactorsrework.battery_terminal.energy_stored.tooltip")));
        this.addScreenElement(new TooltipElement<>(this, 30, 36, 16, 16, Component.translatable("screen.biggerreactorsrework.battery_terminal.input_rate.tooltip")));
        this.addScreenElement(new TooltipElement<>(this, 30, 54, 16, 16, Component.translatable("screen.biggerreactorsrework.battery_terminal.output_rate.tooltip")));

        RenderedElement<BatteryTerminalContainer> energyGauge = new RenderedElement<>(this, 8, 18, 18, 64, 0, 0, Component.empty());
        energyGauge.onRender = (@Nonnull GuiGraphics graphics, int mX, int mY) -> CommonRender.renderEnergyGauge(graphics,
                energyGauge, batteryState.energyStored, batteryState.energyCapacity);
        this.addScreenElement(energyGauge);
    }

    @Override
    public void render(@Nonnull GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        super.render(graphics, mouseX, mouseY, partialTicks);
        int x = this.getGuiLeft() + READOUT_X;
        int y = this.getGuiTop();
        int color = GuiTheme.textColor();

        GuiArt.scrollingText(graphics, this.getFont(), RenderHelper.formatValue(batteryState.energyStored, "FE") + " / "
                + RenderHelper.formatValue(batteryState.energyCapacity, "FE"), x, y + 22, READOUT_WIDTH, color);
        GuiArt.scrollingText(graphics, this.getFont(), Component.translatable("screen.biggerreactorsrework.battery_terminal.input_rate",
                RenderHelper.formatValue(batteryState.lastInput, "FE/t")).getString(), x, y + 40, READOUT_WIDTH, color);
        GuiArt.scrollingText(graphics, this.getFont(), Component.translatable("screen.biggerreactorsrework.battery_terminal.output_rate",
                RenderHelper.formatValue(batteryState.lastOutput, "FE/t")).getString(), x, y + 58, READOUT_WIDTH, color);
        GuiArt.scrollingText(graphics, this.getFont(), Component.translatable("screen.biggerreactorsrework.battery_terminal.summary",
                batteryState.cellCount, RenderHelper.formatValue(batteryState.transferLimit, "FE/t"),
                batteryState.inletCount, batteryState.outletCount).getString(), this.getGuiLeft() + 8, y + 78, WIDTH - 16, color);

        // Empty battery slots explain themselves; with an item in them the item's own tooltip shows instead.
        if (this.hoveredSlot != null && this.hoveredSlot.index < 2 && !this.hoveredSlot.hasItem() && this.menu.getCarried().isEmpty()) {
            String key = this.hoveredSlot.index == 0 ? "discharge_slot" : "charge_slot";
            List<Component> lines = Arrays.stream(Component.translatable("screen.biggerreactorsrework.battery_terminal." + key + ".tooltip")
                    .getString().split("\n")).map(line -> (Component) Component.literal(line)).toList();
            graphics.renderComponentTooltip(this.getFont(), lines, mouseX, mouseY);
        }
    }

    @Override
    protected void drawBackground(@Nonnull GuiGraphics graphics, int x, int y) {
        GuiArt.panel(graphics, x, y, WIDTH, HEIGHT, this.frame());
        GuiArt.fill(graphics, x + 8, y + 74, x + WIDTH - 8, y + 75, GuiArt.SEPARATOR);
        GuiIcon.BATTERY.draw(graphics, x + 33, y + 18);
        GuiIcon.ENERGY_GENERATION_RATE.draw(graphics, x + 32, y + 37);
        GuiIcon.ENERGY_GENERATION_RATE.draw(graphics, x + 32, y + 55);

        drawBatterySlot(graphics, x + DISCHARGE_X - 1, y + DISCHARGE_Y - 1, DISCHARGE_RING, true);
        drawBatterySlot(graphics, x + CHARGE_X - 1, y + CHARGE_Y - 1, CHARGE_RING, false);
        GuiArt.playerInventory(graphics, x + 7, y + INVENTORY_Y - 1);

        int earX = x - GuiFrame.TAB_SIZE;
        this.frame().ear(graphics, earX, y + ARMOR_EAR_Y, ARMOR_EAR_HEIGHT, true);
        for (int i = 0; i < 4; i++) {
            GuiArt.slot(graphics, x + ARMOR_X - 1, y + ARMOR_Y - 1 + i * 18, 18);
        }
        GuiArt.slot(graphics, x + ARMOR_X - 1, y + OFFHAND_Y - 1, 18);
    }

    /**
     * Slot with a colored ring and, to its right, a plus (energy into the battery) or a minus (energy out of it).
     */
    private static void drawBatterySlot(GuiGraphics graphics, int slotX, int slotY, int ringColor, boolean plus) {
        GuiArt.ring(graphics, slotX - 2, slotY - 2, RING, ringColor);
        GuiArt.slot(graphics, slotX, slotY, 18);
        int glyphX = slotX + RING;
        int glyphY = slotY + 6;
        GuiArt.fill(graphics, glyphX, glyphY + 2, glyphX + 5, glyphY + 3, ringColor);
        if (plus) {
            GuiArt.fill(graphics, glyphX + 2, glyphY, glyphX + 3, glyphY + 5, ringColor);
        }
    }

    private boolean onArmorTab(double mouseX, double mouseY) {
        int earX = this.getGuiLeft() - GuiFrame.TAB_SIZE;
        int earY = this.getGuiTop() + ARMOR_EAR_Y;
        return mouseX >= earX && mouseX < this.getGuiLeft() && mouseY >= earY && mouseY < earY + ARMOR_EAR_HEIGHT;
    }

    @Override
    protected boolean hasClickedOutside(double mouseX, double mouseY, int guiLeft, int guiTop, int button) {
        return super.hasClickedOutside(mouseX, mouseY, guiLeft, guiTop, button) && !this.onArmorTab(mouseX, mouseY);
    }

    @Override
    protected GuiFrame frame() {
        return GuiFrame.BATTERY;
    }

    @Override
    public boolean hasAppearanceSettings() {
        return true;
    }
}
