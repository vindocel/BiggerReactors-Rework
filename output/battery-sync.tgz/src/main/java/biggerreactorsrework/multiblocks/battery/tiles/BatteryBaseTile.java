package biggerreactorsrework.multiblocks.battery.tiles;

import biggerreactorsrework.core.modular.tile.ModularTile;
import biggerreactorsrework.core.multiblock.IMultiblockTile;
import biggerreactorsrework.core.multiblock.common.IPersistentMultiblockTile;
import biggerreactorsrework.core.multiblock.rectangular.IRectangularMultiblockTile;
import biggerreactorsrework.core.multiblock.touching.ITouchingMultiblockTile;
import biggerreactorsrework.multiblocks.battery.BatteryMultiblockController;
import biggerreactorsrework.multiblocks.battery.blocks.BatteryBaseBlock;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public class BatteryBaseTile extends ModularTile implements IMultiblockTile<BatteryBaseTile, BatteryBaseBlock, BatteryMultiblockController>,
        IRectangularMultiblockTile<BatteryBaseTile, BatteryBaseBlock, BatteryMultiblockController>,
        IPersistentMultiblockTile<BatteryBaseTile, BatteryBaseBlock, BatteryMultiblockController>,
        ITouchingMultiblockTile<BatteryBaseTile, BatteryBaseBlock, BatteryMultiblockController> {
    public BatteryBaseTile(BlockEntityType<?> tileEntityTypeIn, BlockPos pos, BlockState state) {
        super(tileEntityTypeIn, pos, state);
    }
    
    @Override
    public final BatteryMultiblockController createController() {
        if (level == null) {
            throw new IllegalStateException("Attempt to create controller with null world");
        }
        return new BatteryMultiblockController(level);
    }
    
    public void runRequest(String requestName, Object requestData) {
        if (nullableController() != null) {
            controller().runRequest(requestName, requestData);
        }
    }
}
