package biggerreactorsrework.multiblocks.battery.client;

import biggerreactorsrework.client.CommonRender;
import biggerreactorsrework.client.GuiArt;
import biggerreactorsrework.client.GuiFrame;
import biggerreactorsrework.client.GuiIcon;
import biggerreactorsrework.client.GuiTheme;
import biggerreactorsrework.core.client.gui.RenderHelper;
import biggerreactorsrework.core.client.gui.elements.RenderedElement;
import biggerreactorsrework.core.client.gui.elements.TooltipElement;
import biggerreactorsrework.core.client.gui.screens.ModScreen;
import biggerreactorsrework.multiblocks.battery.containers.BatteryTerminalContainer;
import biggerreactorsrework.multiblocks.battery.state.BatteryState;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import javax.annotation.Nonnull;

/**
 * Battery terminal: the charge bar on the left, the stored energy and the last tick's input and output beside it, and
 * the limits the cells give underneath.
 */
@OnlyIn(Dist.CLIENT)
public class BatteryTerminalScreen extends ModScreen<BatteryTerminalContainer> {
    
    private static final int WIDTH = 176;
    private static final int HEIGHT = 92;
    private static final int READOUT_X = 50;
    private static final int READOUT_WIDTH = WIDTH - READOUT_X - 8;
    
    private final BatteryState batteryState;
    
    public BatteryTerminalScreen(BatteryTerminalContainer container, Inventory playerInventory, Component title) {
        super(container, playerInventory, Component.translatable("screen.biggerreactorsrework.battery_terminal"), WIDTH, HEIGHT);
        this.batteryState = (BatteryState) this.getMenu().getGuiPacket();
    }
    
    @Override
    public void init() {
        super.init();
        this.titleLabelX = (this.imageWidth - this.font.width(this.getTitle())) / 2;
        
        this.addScreenElement(new TooltipElement<>(this, 30, 18, 16, 16, Component.translatable("screen.biggerreactorsrework.battery_terminal.energy_stored.tooltip")));
        this.addScreenElement(new TooltipElement<>(this, 30, 36, 16, 16, Component.translatable("screen.biggerreactorsrework.battery_terminal.input_rate.tooltip")));
        this.addScreenElement(new TooltipElement<>(this, 30, 54, 16, 16, Component.translatable("screen.biggerreactorsrework.battery_terminal.output_rate.tooltip")));
        
        RenderedElement<BatteryTerminalContainer> energyGauge = new RenderedElement<>(this, 8, 18, 18, 64, 0, 0, Component.empty());
        energyGauge.onRender = (@Nonnull GuiGraphics graphics, int mX, int mY) -> CommonRender.renderEnergyGauge(graphics,
                energyGauge, batteryState.energyStored, batteryState.energyCapacity);
        this.addScreenElement(energyGauge);
    }
    
    @Override
    public void render(@Nonnull GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        super.render(graphics, mouseX, mouseY, partialTicks);
        int x = this.getGuiLeft() + READOUT_X;
        int y = this.getGuiTop();
        int color = GuiTheme.textColor();
        
        GuiArt.scrollingText(graphics, this.getFont(), RenderHelper.formatValue(batteryState.energyStored, "FE") + " / "
                + RenderHelper.formatValue(batteryState.energyCapacity, "FE"), x, y + 22, READOUT_WIDTH, color);
        GuiArt.scrollingText(graphics, this.getFont(), Component.translatable("screen.biggerreactorsrework.battery_terminal.input_rate",
                RenderHelper.formatValue(batteryState.lastInput, "FE/t")).getString(), x, y + 40, READOUT_WIDTH, color);
        GuiArt.scrollingText(graphics, this.getFont(), Component.translatable("screen.biggerreactorsrework.battery_terminal.output_rate",
                RenderHelper.formatValue(batteryState.lastOutput, "FE/t")).getString(), x, y + 58, READOUT_WIDTH, color);
        
        GuiArt.scrollingText(graphics, this.getFont(), Component.translatable("screen.biggerreactorsrework.battery_terminal.summary",
                batteryState.cellCount, RenderHelper.formatValue(batteryState.transferLimit, "FE/t"),
                batteryState.inletCount, batteryState.outletCount).getString(), this.getGuiLeft() + 30, y + 76, WIDTH - 38, color);
    }
    
    @Override
    protected void drawBackground(@Nonnull GuiGraphics graphics, int x, int y) {
        GuiArt.panel(graphics, x, y, WIDTH, HEIGHT, this.frame());
        GuiArt.fill(graphics, x + 30, y + 72, x + WIDTH - 8, y + 73, GuiArt.SEPARATOR);
        GuiIcon.BATTERY.draw(graphics, x + 33, y + 18);
        GuiIcon.ENERGY_GENERATION_RATE.draw(graphics, x + 32, y + 37);
        GuiIcon.ENERGY_GENERATION_RATE.draw(graphics, x + 32, y + 55);
    }
    
    @Override
    protected GuiFrame frame() {
        return GuiFrame.BATTERY;
    }
    
    @Override
    public boolean hasAppearanceSettings() {
        return true;
    }
}
