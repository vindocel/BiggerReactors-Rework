package biggerreactorsrework.multiblocks.battery.tiles;

import biggerreactorsrework.core.registry.RegisterTile;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public class BatteryCellTile extends BatteryBaseTile {
    
    @RegisterTile("battery_cell")
    public static final BlockEntityType.BlockEntitySupplier<BatteryCellTile> SUPPLIER = new RegisterTile.Producer<>(BatteryCellTile::new);
    
    public BatteryCellTile(BlockEntityType<?> TYPE, BlockPos pos, BlockState state) {
        super(TYPE, pos, state);
    }
}
