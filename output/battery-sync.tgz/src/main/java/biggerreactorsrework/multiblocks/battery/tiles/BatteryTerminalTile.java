package biggerreactorsrework.multiblocks.battery.tiles;

import biggerreactorsrework.core.client.gui.api.IHasUpdatableState;
import biggerreactorsrework.core.registry.RegisterTile;
import biggerreactorsrework.multiblocks.battery.blocks.BatteryTerminal;
import biggerreactorsrework.multiblocks.battery.containers.BatteryTerminalContainer;
import biggerreactorsrework.multiblocks.battery.state.BatteryState;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public class BatteryTerminalTile extends BatteryBaseTile implements MenuProvider, IHasUpdatableState<BatteryState> {
    
    @RegisterTile("battery_terminal")
    public static final BlockEntityType.BlockEntitySupplier<BatteryTerminalTile> SUPPLIER = new RegisterTile.Producer<>(BatteryTerminalTile::new);
    
    public BatteryTerminalTile(BlockEntityType<?> TYPE, BlockPos pos, BlockState state) {
        super(TYPE, pos, state);
    }
    
    public final BatteryState batteryState = new BatteryState(this);
    
    @Override
    public BatteryState getState() {
        this.updateState();
        return batteryState;
    }
    
    @Override
    public void updateState() {
        if (nullableController() != null) {
            controller().updateDataPacket(batteryState);
        }
    }
    
    @Override
    public Component getDisplayName() {
        return Component.translatable(BatteryTerminal.INSTANCE.getDescriptionId());
    }
    
    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int windowId, Inventory playerInventory, Player player) {
        return new BatteryTerminalContainer(windowId, this.worldPosition, playerInventory.player);
    }
}
