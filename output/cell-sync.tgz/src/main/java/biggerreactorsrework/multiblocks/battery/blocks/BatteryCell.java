package biggerreactorsrework.multiblocks.battery.blocks;

import biggerreactorsrework.core.modular.block.IConnectedTexture;
import biggerreactorsrework.core.multiblock.IAssemblyStateBlock;
import biggerreactorsrework.core.registry.RegisterBlock;
import biggerreactorsrework.multiblocks.battery.tiles.BatteryCellTile;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;

/**
 * Interior block of the battery. Each cell both stores energy and widens the input and output limits, so the battery
 * grows linearly with the cell count. Disassembled it shows the bare body, assembled it lights its core, and the core
 * is animated while the battery holds energy. Neighbouring cells join their textures, and their cores join vertically.
 */
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public class BatteryCell extends BatteryBaseBlock implements IAssemblyStateBlock, IConnectedTexture {
    
    public static final BooleanProperty CHARGED = BooleanProperty.create("charged");
    
    @RegisterBlock(name = "battery_cell", tileEntityClass = BatteryCellTile.class)
    public static final BatteryCell INSTANCE = new BatteryCell();
    
    public BatteryCell() {
        super();
        registerDefaultState(defaultBlockState().setValue(CHARGED, false));
    }
    
    @Override
    protected void buildStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(CHARGED);
    }
    
    @Override
    public boolean isGoodForInterior() {
        return true;
    }
    
    @Override
    public boolean isGoodForExterior() {
        return false;
    }
    
    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return BatteryCellTile.SUPPLIER.create(pos, state);
    }
}
